using CurriculumEnhancerAPI.Controllers;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System.Net.Http;
using System.Threading.Tasks;
using Xunit;

namespace CurriculumEnhancerAPI.Tests
{
    public class CurriculumControllerTests
    {
        [Fact]
        public async Task AnalyzeCurriculum_ShouldReturnSuggestions_WhenSuccessful()
        {
            // Arrange
            var httpClient = new Mock<HttpClient>();
            var controller = new CurriculumController(httpClient.Object);
            var request = new CurriculumRequest { Text = "Experi�ncia em desenvolvimento de software." };

            // Act
            var result = await controller.AnalyzeCurriculum(request);

            // Assert
            Assert.IsType<OkObjectResult>(result);
            var okResult = result as OkObjectResult;
            Assert.NotNull(okResult.Value);
        }
    }
}
