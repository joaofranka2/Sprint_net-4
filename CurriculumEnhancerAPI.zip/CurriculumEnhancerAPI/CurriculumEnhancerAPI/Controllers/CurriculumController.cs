﻿using CurriculumEnhancerAPI.Controllers;
using CurriculumEnhancerAPI.Services;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System.Threading.Tasks;
using Xunit;

public class CurriculumControllerTests
{
    [Fact]
    public async Task AnalyzeCurriculum_ShouldReturnOkResultWithSuggestions_WhenServiceReturnsData()
    {
        // Arrange
        var mockService = new Mock<ICurriculumAnalysisService>();
        mockService.Setup(service => service.AnalyzeCurriculumAsync(It.IsAny<string>()))
                   .ReturnsAsync(new AnalysisResponse { Suggestions = new[] { "Sugestão A", "Sugestão B" } });

        var controller = new CurriculumController(mockService.Object);
        var request = new CurriculumRequest { Text = "Exemplo de currículo" };

        // Act
        var result = await controller.AnalyzeCurriculum(request);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result);
        var response = Assert.IsType<AnalysisResponse>(okResult.Value);
        Assert.Contains("Sugestão A", response.Suggestions);
    }
}
