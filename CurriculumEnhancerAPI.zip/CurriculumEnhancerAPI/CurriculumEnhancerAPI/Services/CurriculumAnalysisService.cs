﻿// Services/CurriculumAnalysisService.cs

using Microsoft.Extensions.Configuration;
using Microsoft.ML;
using Microsoft.ML.Data;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;

namespace CurriculumEnhancerAPI.Services
{
    public class CurriculumAnalysisService : ICurriculumAnalysisService
    {
        private readonly HttpClient _httpClient;
        private readonly string? _baseUrl;
        private readonly MLContext _mlContext;
        private readonly ITransformer _sentimentModel;

        public CurriculumAnalysisService(HttpClient httpClient, IConfiguration configuration)
        {
            _httpClient = httpClient;
            _baseUrl = configuration["CurriculumAnalysisApi:BaseUrl"];
            _mlContext = new MLContext();

            // Carregar e treinar o modelo de sentimento
            var data = _mlContext.Data.LoadFromTextFile<SentimentData>("sentimentdata.tsv", separatorChar: '\t', hasHeader: true);
            var pipeline = _mlContext.Transforms.Text.FeaturizeText("Features", nameof(SentimentData.Text))
                            .Append(_mlContext.BinaryClassification.Trainers.SdcaLogisticRegression(labelColumnName: "Label", featureColumnName: "Features"));
            _sentimentModel = pipeline.Fit(data);
        }

        public async Task<AnalysisResponse> AnalyzeCurriculumAsync(string text)
        {
            if (string.IsNullOrEmpty(_baseUrl))
            {
                throw new InvalidOperationException("A URL base da API de análise de currículo não foi configurada.");
            }

            var request = new { text, language = "pt" };
            var response = await _httpClient.PostAsJsonAsync($"{_baseUrl}/analyze", request);

            if (response.IsSuccessStatusCode)
            {
                var suggestions = await response.Content.ReadFromJsonAsync<AnalysisResponse>();
                return suggestions ?? new AnalysisResponse { Suggestions = new string[0] };
            }

            return new AnalysisResponse { Suggestions = new string[0] };
        }

        public SentimentPrediction PredictSentiment(string text)
        {
            var predictionEngine = _mlContext.Model.CreatePredictionEngine<SentimentData, SentimentPrediction>(_sentimentModel);
            return predictionEngine.Predict(new SentimentData { Text = text });
        }
    }
}
