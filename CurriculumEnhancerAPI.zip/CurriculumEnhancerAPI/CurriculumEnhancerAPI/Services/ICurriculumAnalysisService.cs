﻿// Services/ICurriculumAnalysisService.cs

namespace CurriculumEnhancerAPI.Services
{
    public interface ICurriculumAnalysisService
    {
        Task<AnalysisResponse> AnalyzeCurriculumAsync(string text);
        SentimentPrediction PredictSentiment(string text);
    }
}
