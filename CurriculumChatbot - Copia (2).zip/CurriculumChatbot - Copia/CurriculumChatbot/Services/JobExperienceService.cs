﻿using System.Collections.Generic;
using System.Threading.Tasks;
using CurriculumManagement.Models;
using CurriculumManagement.Repositories;

namespace CurriculumManagement.Services
{
    public class JobExperienceService
    {
        private readonly IJobExperienceRepository _repository;

        public JobExperienceService(IJobExperienceRepository repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<JobExperience>> GetAllAsync()
        {
            return await _repository.GetAllAsync();
        }

        public async Task<JobExperience> GetByIdAsync(int id)
        {
            return await _repository.GetByIdAsync(id);
        }

        public async Task AddAsync(JobExperience jobExperience)
        {
            await _repository.AddAsync(jobExperience);
        }

        public async Task UpdateAsync(JobExperience jobExperience)
        {
            await _repository.UpdateAsync(jobExperience);
        }

        public async Task DeleteAsync(int id)
        {
            await _repository.DeleteAsync(id);
        }
    }
}
