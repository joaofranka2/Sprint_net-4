﻿using CurriculumManagement.Models;

namespace CurriculumManagement.Repositories
{
    public interface IJobExperienceRepository
    {
        Task<IEnumerable<JobExperience>> GetAllAsync();
        Task<JobExperience> GetByIdAsync(int id);
        Task AddAsync(JobExperience jobExperience);
        Task UpdateAsync(JobExperience jobExperience);
        Task DeleteAsync(int id);
    }
}
