﻿using Microsoft.EntityFrameworkCore;
using CurriculumManagement.Data;
using CurriculumManagement.Models;

namespace CurriculumManagement.Repositories
{
    public class EducationRepository : IEducationRepository
    {
        private readonly ApplicationDbContext _context;

        public EducationRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Education>> GetAllAsync()
        {
            return await _context.Educations.ToListAsync();
        }

        public async Task<Education> GetByIdAsync(int id)
        {
            return await _context.Educations.FindAsync(id);
        }

        public async Task AddAsync(Education education)
        {
            _context.Educations.Add(education);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(Education education)
        {
            _context.Entry(education).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var education = await _context.Educations.FindAsync(id);
            if (education != null)
            {
                _context.Educations.Remove(education);
                await _context.SaveChangesAsync();
            }
        }
    }
}
