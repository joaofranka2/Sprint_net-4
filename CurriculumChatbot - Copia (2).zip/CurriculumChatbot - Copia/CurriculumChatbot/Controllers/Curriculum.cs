﻿namespace CurriculumManagement.Models
{
    public class Curriculum
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Email { get; set; }
        public string Telefone { get; set; }
        public string Endereco { get; set; }
        public ICollection<JobExperience> JobExperiences { get; set; }
        public ICollection<Education> Educations { get; set; }
    }
}
